from calc import multiply


def test_multiply() -> None:
    assert multiply(3, 4) == 12
    assert multiply(-2, 5) == -10
