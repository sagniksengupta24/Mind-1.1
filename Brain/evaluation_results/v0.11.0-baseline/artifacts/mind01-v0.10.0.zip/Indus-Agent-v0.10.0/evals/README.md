# Indus Agent evaluation assets

This directory contains the ordinary local evaluation tasks used by the CLI harness. These files currently cover repository analysis, coding, documentation retrieval, memory, safety, semiconductor topics, and Indian-language explanations.

The ordinary files are legacy v0.9 assets: they do not yet have a fully validated dataset schema or development/regression/blind split. They must not be described as a blind model-quality benchmark.

Versioned deterministic suites live inside the package:

- `indus_agent/eval_suites/action_reliability_v1.json`: 50 model-action cases.
- `indus_agent/eval_suites/truthful_completion_v1.json`: 25 adversarial false-success cases plus positive evidence-mapping controls.
- `indus_agent/eval_suites/real_mutation/manifest.json`: three isolated real-mutation fixtures.

Validate all assets:

```bash
python -m indus_agent.eval validate
```

Run deterministic plumbing and completion regressions:

```bash
python -m indus_agent.eval run --suite regression --mock-model
python -m indus_agent.eval run --suite truthful-completion
```

The first command is explicitly mocked and proves protocol plumbing only. The truthful-completion suite exercises deterministic completion authority; it is not a live-model benchmark.

Live action and mutation evaluations require Ollama and must retain their per-case reports. A genuinely blind holdout must be stored outside implementation visibility and is deferred to the v0.11 semantic-routing release.
