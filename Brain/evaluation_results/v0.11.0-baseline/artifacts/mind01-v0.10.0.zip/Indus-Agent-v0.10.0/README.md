# Indus Agent v0.10.0

Indus Agent is a **local-first AI engineering-agent runtime** for repository work, coding, debugging, verification, semiconductor/VLSI assistance, mathematics, Indian-language technical learning, project memory, and documentation retrieval.

It is not a foundation model. It runs an Ollama-compatible local model and adds the engineering system around it: strict actions, routing, planning, controlled tools, deterministic verification, persistent sessions, provenance-aware project knowledge, receipts, rollback, traces, and evaluations.

## What changed in v0.10.0

v0.10.0 makes completion status depend on a typed task contract and task-relevant evidence. Before mutation, the runtime records target and forbidden scope, expected artifacts and symbols, behavioral and regression requirements, required evidence types, rollback conditions, and completion criteria.

Each verification result declares its evidence type, mapped requirement IDs, state hash, proven properties, and explicitly unproven properties. Compilation proves syntax only. AST structure proves limited executable-source properties only. Import, symbol, signature, behavioral, regression, patch-review, and receipt-integrity evidence remain distinct.

`CompletionAuthority` is the single final-status decision point for the agent, correction controller, and real-mutation harness. A mutation is `verified` only when every mandatory requirement has current passing evidence, scope and receipts match, no mandatory check was skipped, no blocking finding remains, and no unauthorized mutation occurred. Failed post-write correction attempts are restored before another attempt.

The deterministic `truthful-completion-v1` suite contains 25 adversarial false-success cases plus positive mapping controls:

```bash
python -m indus_agent.eval run --suite truthful-completion
```

## v0.9.1 action protocol foundation

The v0.9.1 foundation established real local-model action reliability. The active model protocol is exactly one versioned JSON object per turn; XML, tagged text, Markdown-wrapped alternatives, and plain-prose fallback are not active runtime formats.

Tool call:

```json
{"schema_version":"1.0","response_type":"tool_call","tool":"read_file","arguments":{"path":"README.md"}}
```

Final response:

```json
{"schema_version":"1.0","response_type":"final","status":"unverified","summary":"Repository inspection is complete.","evidence_refs":[]}
```

Each turn has one runtime-selected mode:

- `ACTION_REQUIRED`: only a permitted tool call is valid.
- `FINAL_ALLOWED`: a permitted tool call or final response is valid.
- `REPAIR_REQUIRED`: only a compact correction of the preceding invalid object is valid.

The parser classifies failures as `NO_ACTION`, `MALFORMED_JSON`, `TRUNCATED_OUTPUT`, `UNKNOWN_TOOL`, `MISSING_ARGUMENT`, `WRONG_ARGUMENT_TYPE`, `EXTRA_ARGUMENT`, `MULTIPLE_ACTIONS`, `CONFLICTING_ACTIONS`, `PROSE_AROUND_ACTION`, mode mismatches, schema-version mismatch, oversize, repeated-invalid, unsafe-action, or internal-parser failures. Incident records contain hashes and redacted bounded excerpts, never unrestricted raw output.

The Ollama client detects JSON Schema support and uses a schema object when supported, otherwise it falls back to JSON mode. The parser and server policy still validate every response. Tools are exposed by current phase: inspection cannot see mutation tools, mutation requires an approved mutation route plus prior inspection, and verification tools appear only where route and server capabilities permit them.

Parser repair is limited to two compact attempts. Safe extraction can recover exactly one complete, fully valid JSON object from harmless surrounding structural noise; it records an incident and never guesses tools or arguments.

Live file mutation follows:

```text
snapshot/receipt -> mutation -> deterministic verification -> patch review
                 -> accept, compact repair, or receipt-backed rollback
```

Completion status is runtime-authoritative. A model request for `verified` is downgraded without a referenced passing evidence record, while blocking verification or patch review forces failure.

The versioned action benchmark contains 50 inspection, mutation, verification, recovery, and final-response cases. The real-mutation suite contains three fixtures that fail preconditions before execution: syntax repair, failing-test repair, and a hidden-acceptance small feature. Invalid Python is stored as `broken.py.fixture` and materialized only in the isolated workspace.

Local deterministic evidence for this checkout is documented by the test and evaluation commands below. A fresh real Ollama result must be generated before claiming the action-validity targets or coding success; mocked results are labeled separately.

## Execution lifecycle

The runtime now follows an explicit lifecycle:

```text
RECEIVE → CLASSIFY → PLAN → GATHER_CONTEXT → MODEL_CALL → PARSE
        → POLICY_CHECK → EXECUTE → OBSERVE → VERIFY/REVIEW → REPAIR_OR_FINISH
```

```text
Task
  ↓
Current phase
  ↓
Allowed tool subset
  ↓
Constrained model response
  ↓
Strict parser
  ├── Valid → policy → execute
  └── Invalid → classify → compact repair
                              ├── Valid → execute
                              └── Repeated failure → stop
```

The engineering foundation also includes:

- server-authoritative API privileges and trusted Ollama endpoint policy;
- real API conversation restoration with bounded context and summaries;
- hierarchical specialist routing and reusable skill selection;
- typed execution plans for non-trivial or mutating work;
- pluggable deterministic verification with structured evidence;
- bounded typed parser repair, duplicate-action detection, repeated-error detection, and no-progress termination;
- concurrency-safe receipt and trace hash-chain updates;
- SQLite WAL and busy timeouts for runtime stores;
- provenance-aware project knowledge for files, symbols, modules, imports, and definitions;
- evaluation metadata, verification requirements, and false-success tracking;
- one centralized package version and clean-release tooling.

Benchmark-specific canned answers and exact benchmark prompt classifiers are not used by the runtime.

## Reality check

On a 16 GB MacBook Air, use a compact local model such as `qwen2.5-coder:7b`. The runtime can make a small model more reliable and auditable, but orchestration cannot turn it into a frontier model. Quality remains dependent on the selected model, repository, available verification tools, and task difficulty.

## Requirements

- Python 3.10 or newer; Python 3.11+ recommended
- Ollama for live model calls
- No mandatory cloud service
- Optional local compilers, test runners, linters, Verilog tools, or Docker for additional verification/isolation

```bash
brew install ollama
ollama serve
ollama pull qwen2.5-coder:7b
```

Optional documentation embeddings:

```bash
ollama pull nomic-embed-text
```

## Quick start

```bash
python3 -m indus_agent.cli doctor
python3 -m indus_agent.cli ask "Inspect this repository and summarize its architecture" --workspace .
python3 scripts/run_checks.py
```

Dry-run evaluation without a model call:

```bash
python3 -m indus_agent.cli eval evals/basic.json --dry-run --workspace .
```

## Operating modes

The default is `read-only`.

- `read-only`: inspection, search, retrieval, status, and safe answers only.
- `propose`: permits indexes, project-knowledge refresh, and patch proposals; direct source mutation remains blocked.
- `write-approved`: source mutation requires server/CLI write capability and explicit approval.
- `unsafe`: enables the maximum configured capability but does not bypass schemas, workspace boundaries, command policy, or verification reporting.

Examples:

```bash
python3 -m indus_agent.cli index-code --workspace . --mode propose
python3 -m indus_agent.cli ask "Fix the failing parser test" \
  --workspace . --mode write-approved --allow-write --yes
python3 -m indus_agent.cli ask "Run the targeted tests" \
  --workspace . --mode write-approved --allow-shell --yes
```

## Intelligence architecture

### Hierarchical routing

The router selects a structured specialist profile, confidence, context requirements, permitted tools, verification strategy, complexity, and planning requirement. Current specialist categories include:

- general reasoning;
- repository understanding;
- code modification and debugging;
- testing and verification;
- docs/RAG and memory retrieval;
- mathematics;
- Python, C/C++, and Verilog verification;
- security review.

Routing uses deterministic capability/file signals where reliable and conservative general fallback elsewhere. It does not use hardcoded benchmark answers.

### Typed planning

Non-trivial and mutation tasks receive an execution plan containing objective, assumptions, constraints, steps, likely files, tools, risk, verification requirements, and completion criteria. Plans are execution metadata—not unrestricted chain-of-thought.

### Reusable skills

Skills define trigger conditions, tool permissions, procedure, verification requirements, failure conditions, and output expectations. Initial skills cover repository analysis, safe editing, debugging, feature work, refactoring, tests, Python verification, API security, Verilog verification, and documentation retrieval.

### Deterministic verification

The verification engine reports structured evidence rather than a vague “looks correct.” Available adapters include:

- Python compilation and repository tests;
- JSON parsing;
- C/C++ compiler syntax checks;
- Verilog syntax/simulation when Icarus Verilog is installed;
- JavaScript/TypeScript project-script discovery and checks when available.

A change is not reported as verified unless a relevant check actually passes. Missing tools are reported as unavailable or unverified.

## API security model

Start a default loopback, read-only API:

```bash
INDUS_API_TOKEN=dev-token python3 -m indus_agent.cli serve-api \
  --workspace . --host 127.0.0.1 --port 8765 \
  --cors-origin http://localhost:3000
```

An elevated API must be explicitly configured by the server operator:

```bash
INDUS_API_TOKEN=dev-token python3 -m indus_agent.cli serve-api \
  --workspace . --mode write-approved --allow-write --auto-approve
```

Security invariants:

- clients may request less privilege, never more than the server maximum;
- clients cannot choose an arbitrary model or Ollama URL;
- non-loopback binding requires a token;
- elevated capabilities require a token;
- request size, prompt size, step count, and concurrency are bounded;
- mutation routes require server-enabled mode, write capability, and approval policy;
- internal exceptions are not returned verbatim as 500 responses.

See `docs/api.md`, `SECURITY.md`, and `THREAT_MODEL.md`.

## Persistent sessions

`session_id` now restores actual prior conversation messages before an API model call. The session store:

- keeps recent turns;
- deterministically summarizes omitted older turns;
- bounds stored content and trace size;
- separates sessions;
- uses SQLite WAL and a busy timeout.

Conversation history, long-term memory, documentation retrieval, project knowledge, and temporary tool observations remain separate sources.

## Project knowledge

Project knowledge is a lightweight SQLite graph with provenance and source hashes. It currently represents files, symbols, modules, `defines`, and `imports` relationships and invalidates source-derived facts when files change.

Inside the agent, use `refresh_knowledge` and `query_knowledge`. From the CLI:

```bash
python3 -m indus_agent.cli knowledge refresh --workspace . --mode propose
python3 -m indus_agent.cli knowledge query Agent --workspace .
python3 -m indus_agent.cli knowledge status --workspace .
```

Through the API:

```text
GET  /knowledge
GET  /knowledge?q=Agent&limit=20
POST /knowledge/refresh   {"path":".", "mode":"propose"}
```

## File and execution safety

File safety blocks workspace traversal, symlink escape, runtime-state access, unsafe writes, binary reads, and oversized reads.

Command execution uses argument arrays with `shell=False`, allowlisted executables, metacharacter checks, a sanitized environment, controlled working/runtime directories, timeout handling, output limits, and process-group termination where supported.

**Host execution is not a sandbox.** Repository-controlled code can still be dangerous. An optional external container/process isolation layer should be used for untrusted projects.

## Receipts, rollback, and traces

Successful mutations create verified receipts and backups under `.indus_agent/receipts/`. Tool and agent events are stored under `.indus_agent/traces/`.

Receipt and trace chain-head updates are protected by process/thread locks and atomic replacement. Chain verification traverses hashes from the current head and detects broken, disconnected, cyclic, or forked records.

```bash
python3 -m indus_agent.cli receipts --workspace . list
python3 -m indus_agent.cli traces --workspace . list
python3 -m indus_agent.cli rollback <receipt_id> \
  --workspace . --mode write-approved --yes
```

## Documentation, memory, and code indexes

```bash
python3 -m indus_agent.cli index-docs docs --workspace . --mode propose
python3 -m indus_agent.cli search-docs clock --workspace .
python3 -m indus_agent.cli index-code --workspace . --mode propose
python3 -m indus_agent.cli memory --workspace . list
```

Documentation hits carry line citations. Long-term memory is tagged and ranked. Secret-looking values are redacted according to the implemented patterns, but redaction should not be treated as perfect data-loss prevention.

## Evaluation

Evaluation runs record:

- Indus Agent version and Git commit when available;
- dataset version, model, mode, max steps, Python, and platform;
- success rate, parser failure rate, verification pass rate, false-success count, retries, steps, and duration;
- per-task verification evidence.

Tasks may set `requires_verification: true`. A textually correct-looking answer without passed deterministic evidence then counts as a false success and fails.

Validate all versioned assets and run the explicitly mocked protocol regression:

```bash
python -m indus_agent.eval validate
python -m indus_agent.eval run --suite regression --mock-model
```

Run real-model evaluations separately:

```bash
python -m indus_agent.eval action-benchmark --model qwen2.5-coder:7b
python -m indus_agent.eval smoke --suite real-mutation --model qwen2.5-coder:7b
python -m indus_agent.eval parser-report evaluation_results/<action-run>
```

Reports record the model/digest when available, Ollama version, constraint mode, benchmark and configuration hashes, parser taxonomy, repair outcomes, latency, tool distribution, semantic expected-family match, fixture preconditions, acceptance, rollbacks, unsafe actions, and false successes. Structural validity and semantic tool choice are separate metrics.

The current ordinary task files are legacy unsplit assets. The action and truthful-completion suites are versioned regression assets. A genuinely blind holdout must remain outside implementation visibility and is a v0.11 release requirement.

## Validation and release

Canonical checks:

```bash
python3 -m pytest -q
python3 -m compileall -q indus_agent tests
python3 scripts/run_checks.py
python3 -m pip wheel . --no-deps --wheel-dir dist
```

Create a clean source ZIP without runtime databases, traces, receipts, caches, historical outputs, or secrets:

```bash
python3 scripts/build_release.py --output-dir dist
```

## Runtime storage

All runtime state lives under `.indus_agent/`, including sessions, memory, docs, code index, project knowledge, traces, receipts, patches, dirty-state records, and evaluation runs. This directory is excluded from clean releases.

## Known limitations

- Not a foundation model and not guaranteed to solve arbitrary tasks.
- Not a production multi-tenant platform.
- No complete RBAC, rate-limiting service, distributed lock, signed remote audit log, or hardened container sandbox.
- Host-executed tools can run repository-controlled code.
- Verification quality depends on installed compilers and test tools.
- The project-knowledge graph is intentionally small, not a semantic code intelligence platform.
- Local redaction patterns may miss uncommon secrets.
- Live-model quality must be measured with blind holdouts; dry-run tests prove runtime behavior, not intelligence.
