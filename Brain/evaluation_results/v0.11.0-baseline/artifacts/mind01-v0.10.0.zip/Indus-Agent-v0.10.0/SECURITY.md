# Security Policy

## Supported status

Indus Agent v0.10.0 is a research-grade local prototype. It is not approved for untrusted public deployment or multi-tenant use.

## Trust model

Trusted:

- the local operator
- server startup configuration
- the selected local Ollama installation

Untrusted:

- user prompts
- model output
- repository contents
- tool arguments proposed by the model
- HTTP request bodies

Repository text and retrieved documentation are data, never policy.

## Security invariants

- Clients cannot exceed the server maximum mode or capabilities.
- Model and Ollama endpoint selection are server-controlled.
- Source writes require an elevated mode, server write capability, schema permission, and approval.
- Shell execution requires an elevated mode, server shell capability, schema permission, and approval.
- All file operations remain inside the resolved workspace and reject runtime-storage access.
- Mutations require pre-dispatch traces and produce verified receipts.
- API error responses redact expected secrets and suppress unexpected internal exception text.
- Release artifacts exclude `.indus_agent` and local databases.
- Constrained decoding never bypasses strict parsing or server policy.
- Safe JSON extraction requires exactly one complete, valid, permitted object and never guesses mutation commands or arguments.
- Mutation tools are hidden outside authorized mutation phases.
- `verified` completion requires runtime-owned deterministic evidence.
- Syntax-only evidence cannot satisfy behavioral requirements.
- Stale, pre-mutation, skipped, mismatched-receipt, and out-of-scope evidence cannot produce verified completion.

## Host-execution warning

Allowlisted commands run on the host. This is not a sandbox. Running Python, pytest, or project build tools can execute malicious repository code. Use a disposable container or VM for untrusted repositories.

## Reporting

Do not include live credentials, private repository content, session databases, traces, or receipt backups in a vulnerability report. Provide a minimal reproduction and affected version.
