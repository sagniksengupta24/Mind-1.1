from __future__ import annotations

import subprocess
import sys


COMMANDS = [
    [sys.executable, "-m", "pytest", "-q"],
    [sys.executable, "-m", "compileall", "-q", "indus_agent", "tests", "scripts"],
    [sys.executable, "-m", "indus_agent.eval", "validate"],
    [sys.executable, "-m", "indus_agent.eval", "run", "--suite", "regression", "--mock-model"],
    [sys.executable, "-m", "indus_agent.eval", "run", "--suite", "truthful-completion"],
    [
        sys.executable,
        "-m",
        "indus_agent.cli",
        "eval",
        "evals/basic.json",
        "--dry-run",
        "--workspace",
        ".",
        "--task-timeout",
        "5",
        "--repair-attempts",
        "1",
    ],
    [sys.executable, "scripts/check_package.py"],
]



def main() -> int:
    for command in COMMANDS:
        print("+", " ".join(command))
        completed = subprocess.run(command)
        if completed.returncode != 0:
            return completed.returncode
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
