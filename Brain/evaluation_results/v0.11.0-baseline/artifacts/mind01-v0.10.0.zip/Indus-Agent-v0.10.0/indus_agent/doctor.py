from __future__ import annotations

import json
import platform
import shutil
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass


@dataclass
class Check:
    name: str
    ok: bool
    detail: str
    fix: str = ""


def run_doctor(model: str, ollama_url: str) -> list[Check]:
    checks = [
        Check(
            "python",
            True,
            f"{sys.version.split()[0]} on {platform.platform()}",
        )
    ]
    ollama_path = shutil.which("ollama")
    checks.append(
        Check(
            "ollama-cli",
            ollama_path is not None,
            ollama_path or "not found",
            "Install Ollama, then run `ollama serve`.",
        )
    )

    tags = fetch_ollama_tags(ollama_url)
    if tags is None:
        checks.append(
            Check(
                "ollama-server",
                False,
                f"not reachable at {ollama_url}",
                "Start Ollama with `ollama serve`.",
            )
        )
        checks.append(
            Check(
                "model",
                False,
                f"cannot check `{model}` until Ollama is reachable",
                f"After starting Ollama, run `ollama pull {model}`.",
            )
        )
        return checks

    checks.append(Check("ollama-server", True, f"reachable at {ollama_url}"))
    models = extract_model_names(tags)
    has_model = model in models
    checks.append(
        Check(
            "model",
            has_model,
            f"{model} {'is available' if has_model else 'is not pulled'}",
            f"Run `ollama pull {model}`.",
        )
    )
    return checks


def fetch_ollama_tags(ollama_url: str) -> dict | None:
    request = urllib.request.Request(f"{ollama_url.rstrip('/')}/api/tags")
    try:
        with urllib.request.urlopen(request, timeout=3) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None


def extract_model_names(tags: dict) -> set[str]:
    models = tags.get("models", [])
    names = set()
    for model in models:
        if isinstance(model, dict) and isinstance(model.get("name"), str):
            names.add(model["name"])
            names.add(model["name"].split(":")[0])
    return names


def render_doctor(checks: list[Check]) -> str:
    lines = []
    for check in checks:
        status = "ok" if check.ok else "missing"
        lines.append(f"{status:7} {check.name}: {check.detail}")
        if not check.ok and check.fix:
            lines.append(f"        fix: {check.fix}")
    return "\n".join(lines)
