from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RouteDecision:
    specialist: str
    confidence: float
    required_context: tuple[str, ...]
    permitted_tools: tuple[str, ...]
    verification_strategy: tuple[str, ...]
    estimated_complexity: str
    planning_required: bool
    rationale: str
    mutation_required: bool = False


_SPECIALISTS = {
    "general_reasoning",
    "repository_understanding",
    "code_modification",
    "debugging",
    "testing_verification",
    "documentation_rag",
    "memory_retrieval",
    "mathematics",
    "python_verification",
    "cpp_verification",
    "verilog_verification",
    "security_review",
}

_FILE_RE = re.compile(r"(?:^|\s)([\w./-]+\.(?:py|js|jsx|ts|tsx|c|cc|cpp|h|hpp|v|sv|json|toml|ya?ml|md))(?:\s|$)", re.I)


class HierarchicalRouter:
    """Layered deterministic router with a conservative general fallback.

    It routes by task capabilities and file types, never by exact benchmark prompt.
    The LLM remains responsible for task reasoning; this layer constrains tools and
    selects verification strategies.
    """

    def route(self, prompt: str, workspace: Path) -> RouteDecision:
        text = prompt.lower()
        files = tuple(match.group(1) for match in _FILE_RE.finditer(prompt))
        mutation = bool(re.search(r"\b(edit|modify|fix|patch|update|create|implement|refactor|write to|save)\b", text))
        debugging = bool(re.search(r"\b(error|exception|failing|failure|bug|debug|traceback|white screen)\b", text))
        verification = bool(re.search(r"\b(tests?|testing|verify|verification|compile|lint|build|check|coverage)\b", text))
        security = bool(re.search(r"\b(security|vulnerability|auth|token|cors|ssrf|injection|traversal|permission|privilege)\b", text))
        docs = bool(re.search(r"\b(documentation|docs|readme|explain from docs|rag)\b", text))
        memory = bool(re.search(r"\b(remember|recall|previous decision|as before|our architecture)\b", text))
        math = bool(re.search(r"\b(equation|derive|proof|calculate|mathematics|algebra|calculus|probability)\b", text))

        suffixes = {Path(item).suffix.lower() for item in files}
        if security:
            return self._decision("security_review", 0.93, True, files, ("policy invariants", "security regression tests"), "high", mutation_required=mutation)
        if suffixes & {".v", ".sv"} or re.search(r"\b(verilog|systemverilog|rtl|testbench|fsm|cdc)\b", text):
            return self._decision("verilog_verification", 0.92, True, files, ("HDL syntax", "simulation/formal when available"), "high" if mutation else "medium", mutation_required=mutation)
        if suffixes & {".c", ".cc", ".cpp", ".h", ".hpp"}:
            return self._decision("cpp_verification", 0.9, True, files, ("compiler warnings", "tests"), "high" if mutation else "medium", mutation_required=mutation)
        if suffixes & {".py"} or re.search(r"\b(python|pytest|ruff|mypy|pyright)\b", text):
            specialist = "debugging" if debugging else ("python_verification" if verification else "code_modification" if mutation else "repository_understanding")
            return self._decision(specialist, 0.9, mutation or debugging or bool(files), files, ("python syntax", "targeted tests"), "high" if mutation else "medium", mutation_required=mutation)
        if debugging:
            return self._decision("debugging", 0.86, True, files, ("reproduce", "targeted tests"), "high", mutation_required=mutation)
        if verification:
            return self._decision("testing_verification", 0.84, False, files, ("project checks",), "medium")
        if mutation:
            return self._decision("code_modification", 0.82, True, files, ("file-type checks", "project tests"), "high", mutation_required=True)
        if docs:
            return self._decision("documentation_rag", 0.82, False, files, ("citation/freshness",), "low")
        if memory:
            return self._decision("memory_retrieval", 0.8, False, files, ("provenance",), "low")
        if math:
            return self._decision("mathematics", 0.78, False, files, ("independent calculation",), "medium")
        if files or re.search(r"\b(repository|repo|codebase|workspace|function|class|module|api route)\b", text):
            return self._decision("repository_understanding", 0.78, True, files, ("grounded file inspection",), "medium")
        return self._decision("general_reasoning", 0.55, False, files, (), "low")

    def _decision(
        self,
        specialist: str,
        confidence: float,
        planning_required: bool,
        files: tuple[str, ...],
        verification: tuple[str, ...],
        complexity: str,
        *,
        mutation_required: bool = False,
    ) -> RouteDecision:
        if specialist not in _SPECIALISTS:
            specialist = "general_reasoning"
            confidence = 0.4
        read_tools = ("project_map", "list_files", "read_file", "search_code", "search_symbols", "file_summary", "query_knowledge", "search_docs", "recall")
        mutation_tools = ("refresh_knowledge", "propose_write_file", "propose_edit_file", "write_file", "edit_file")
        execution_specialists = {
            "debugging", "testing_verification", "mathematics", "python_verification",
            "cpp_verification", "verilog_verification", "security_review",
        }
        permitted = read_tools
        if mutation_required:
            permitted += mutation_tools
        if specialist in execution_specialists or mutation_required:
            permitted += ("run_command",)
        return RouteDecision(
            specialist=specialist,
            confidence=confidence,
            required_context=files or ("workspace map when repository-grounded",),
            permitted_tools=permitted,
            verification_strategy=verification,
            estimated_complexity=complexity,
            planning_required=planning_required,
            rationale=f"Capability route: {specialist}; complexity={complexity}.",
            mutation_required=mutation_required,
        )
