from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .modes import AgentMode, parse_agent_mode


@dataclass(frozen=True)
class AgentConfig:
    workspace: Path
    model: str = "qwen2.5-coder:7b"
    ollama_url: str = "http://127.0.0.1:11434"
    max_steps: int = 8
    yes: bool = False
    dry_run: bool = False
    trace: bool = False
    allow_write: bool = False
    allow_shell: bool = False
    mode: AgentMode = AgentMode.READ_ONLY
    request_timeout_seconds: int = 120

    @classmethod
    def build(
        cls,
        workspace: str,
        model: str,
        ollama_url: str,
        max_steps: int,
        yes: bool,
        dry_run: bool,
        trace: bool = False,
        allow_write: bool = False,
        allow_shell: bool = False,
        mode: str | AgentMode = AgentMode.READ_ONLY,
        request_timeout_seconds: int = 120,
    ) -> "AgentConfig":
        root = Path(workspace).expanduser().resolve()
        clean_model = model.strip()
        clean_url = ollama_url.strip().rstrip("/")
        if not clean_model:
            raise ValueError("model must not be empty.")
        if not clean_url:
            raise ValueError("ollama_url must not be empty.")
        if not 1 <= int(max_steps) <= 64:
            raise ValueError("max_steps must be between 1 and 64.")
        if not 1 <= int(request_timeout_seconds) <= 3600:
            raise ValueError("request_timeout_seconds must be between 1 and 3600.")
        return cls(
            workspace=root,
            model=clean_model,
            ollama_url=clean_url,
            max_steps=int(max_steps),
            yes=yes,
            dry_run=dry_run,
            trace=trace,
            allow_write=allow_write,
            allow_shell=allow_shell,
            mode=parse_agent_mode(mode),
            request_timeout_seconds=int(request_timeout_seconds),
        )
