# CLI reference additions for semantic routing

Existing `ask`, API, evaluation, knowledge, receipt, trace, and rollback commands remain available. The v0.11 candidate adds the following evaluation paths:

```bash
# Validate ordinary assets, frozen routing partitions, hashes, and blind-label separation.
python -m indus_agent.eval validate

# Deterministic typed router; no model calls.
python -m indus_agent.eval run --suite semantic-routing --partition development

# Real constrained action selection; retains per-case raw output and metadata.
python -m indus_agent.eval semantic-live \
  --partition regression \
  --model qwen2.5-coder:7b \
  --seed 2101 \
  --timeout 180 \
  --output evaluation_results/v0.11.0-release/regression_runs/run-001.json
```

Valid local labeled partitions are `development`, `regression`, `adversarial`, `capability_mode`, and `ambiguity`. The `blind` partition intentionally refuses local live scoring because its expected labels must come from an external evaluator outside the editable repository.

`semantic-live` performs up to two bounded parser repairs and executes no selected tool. Use the agent `ask` command or API for the actual policy/execution lifecycle; do not interpret routing-harness safety zeros as execution evidence.

```bash
indus-agent --version
python -c "import indus_agent; print(indus_agent.__version__)"
```
