# Semantic routing design — v0.11 candidate

Semantic routing is a deterministic, typed control layer between a request and the model's exact action selection. It does not grant permissions and it does not claim that a task is complete.

```text
request
  -> NormalizedIntent
  -> task class
  -> risk and capability resolution
  -> specialist
  -> tool family
  -> lifecycle-scoped exposure
  -> constrained model action
  -> parser and policy
  -> execution, verification, completion authority
```

## Typed intent and route

`NormalizedIntent` preserves the original request and bounds the normalized goal, target scope, target kind, ambiguity, capabilities, risk, output mode, and interpretation incidents. All categorical values are finite enums, unknown fields are rejected, and `intent_id` is reproducible from the request, mode, capabilities, and inspection state.

`RoutingDecision` records schema version, task class, specialist, tool family, preferred and safe fallback tools, response mode, finite reason code, risk, prior-inspection requirement, required and missing capabilities, diagnostic confidence, contributing signals, and a capability fingerprint. A decision produced under different capabilities or mode is stale and fails closed.

Confidence is diagnostic only. It cannot add a capability, expose a hidden tool, change the server mode, or bypass policy.

## The five stages

1. Task classification chooses inspection, mutation, verification, explanation, planning, or blocked.
2. Risk and capability resolution detects write, shell, network, and runtime-state requirements; mode mismatches; ambiguity; and inspection prerequisites.
3. Specialist selection uses the bounded set `general`, `repository_inspector`, `implementation`, `verification`, `debugging`, `documentation`, and `security_review`.
4. Tool-family selection uses versioned families such as repository discovery, file or symbol inspection, documentation retrieval, verification, proposal, targeted mutation, file creation, patch inspection, final response, clarification, and blocked.
5. The model selects an exact action only from the tools exposed for the current lifecycle state.

The implementation is deterministic today; `model_signals` is retained as an explicit empty field so future model assistance cannot be confused with deterministic evidence.

## Exposure authority

`ToolExposureAuthority` is the policy-aware route-to-schema boundary. It filters by response mode, lifecycle phase, operating mode, capabilities, prior inspection, mutation state, and canonical tool side-effect metadata. The registry validates the selected action again before dispatch.

- Read-only routes never expose source-write tools.
- Propose routes never expose live source-apply tools.
- Existing-file proposals first expose only `read_file`; the exact proposal tool becomes visible after successful inspection.
- Write-approved edits expose read tools before a required inspection and the smallest mutation set afterward.
- Verification after mutation exposes read and verification tools, not unrelated mutation tools.
- A stale capability fingerprint yields no tools.

An unavailable preferred tool is replaced only by a route-defined, semantically safe fallback. No layer invents a tool or widens authority.

## Ambiguity

`none` means the route has enough information. `resolvable` means repository inspection can locate the target without asking the user. `blocking` produces clarification or a block when guessing could mutate the wrong target, expand privilege, lose data, or alter a sensitive interface.

## Evidence boundaries

Deterministic route accuracy measures the router against frozen readable labels. A live routing run measures constrained action selection by the configured Ollama model. Neither proves authorized execution because the semantic live harness deliberately does not dispatch tools. Execution, verification, and completion remain separate runtime stages and require their own retained evidence.

The v0.11 candidate is not a verified release until an independently controlled blind evaluator supplies labels after candidate freeze and at least three complete live runs meet every gate. The repository blind inputs are unlabeled; they are not sufficient evidence by themselves.
